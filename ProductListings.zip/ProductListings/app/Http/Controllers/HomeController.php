<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $total_products = Product::where('has_deleted','0')->count();
        $total_customers = User::where('has_deleted','0')->where('role', 'customer')->count();
        return view('home', compact('total_products', 'total_customers'));
    }


    public function allproducts(){
        $products = Product::where('has_deleted', 0)->orderBy('created_at', 'desc')->get();
        return view('product.customers.allproducts', compact('products'));
    }

    public function product_detail($id){
        $product = Product::findOrFail($id);
        return view('product.customers.details', compact('product'));
    }

    public function customers(){

        $customers = User::where('has_deleted','0')->where('role', 'customer')->get();
        return view('customers', compact('customers'));
    }

}
