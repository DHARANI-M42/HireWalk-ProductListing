<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\Supplier;
use App\Models\Tag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProductController extends Controller
{

    public function create(){

        $categories = Category::all();
        return view('product.create', compact('categories'));
    }

    public function edit($id){

        $product = Product::findOrFail($id);
        $categories = Category::all();
        $tags = Tag::where('product_id', $id)->where('has_deleted', '0')->get();
        $suppliers = Supplier::where('product_id', $id)->where('has_deleted', '0')->get();
        return view('product.edit', compact('product', 'categories', 'tags', 'suppliers'));
    }


    public function listings(){

        $products = Product::where('has_deleted', 0)->orderBy('created_at', 'desc')->get();
        return view('product.listings', compact('products'));
    }

    public function view($id){

        $product = Product::findOrFail($id);
        return view('product.view', compact('product'));
    }



    public function store(Request $request){


        $product = new Product;

        $product->name = $request->input('name');
        $product->description = $request->input('description');
        $product->price = $request->input('price');
        $product->profit_amount = $request->input('profit_amount');
        $product->final_price = $request->input('final_price');
        $product->created_by = Auth::user()->id;
        $product->updated_by = Auth::user()->id;
      
        $selectedCategories = $request->input('categories');


        if (is_array($selectedCategories)) {
            $categoriesString = implode(',', $selectedCategories);
            $product->categories = $categoriesString;
        }
       
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $fileName = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('uploads'), $fileName);
            $product->image =  $fileName;
        }

        $product->save();

        foreach ($request->input('tag_label') as $index => $tag) {
            Tag::create([
                'product_id' => $product->id,
                'tag_name' =>  '#'.$tag,
            ]);
        }


        foreach ($request->input('supplier_label') as $index => $supplier) {
            Supplier::create([
                'product_id' => $product->id,
                'supplier_name' => $supplier,
            ]);
        }


        return redirect()->route('product.listings')->with('success', 'Product Added Successfully');
    }



    public function update(Request $request, $id){

        $product = Product::findOrFail($id);
    
        $product->name = $request->input('name');
        $product->description = $request->input('description');
        $product->price = $request->input('price');
        $product->profit_amount = $request->input('profit_amount');
        $product->final_price = $request->input('final_price');
        $product->created_by = Auth::user()->id;
        $product->updated_by = Auth::user()->id;
    
        $selectedCategories = $request->input('categories');
    
        if (is_array($selectedCategories)) {
            $categoriesString = implode(',', $selectedCategories);
            $product->categories = $categoriesString;
        }
    
        if ($request->hasFile('image')) {
            $oldImagePath = public_path('uploads/' . $product->image);
            if (file_exists($oldImagePath)) {
                unlink($oldImagePath);
            }
    
            $file = $request->file('image');
            $fileName = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('uploads'), $fileName);
            $product->image = $fileName;
        }
    
        $product->update();
    
        // Update or create tags
        if ($request->filled('tag_label')) {
            foreach ($request->input('tag_label') as $index => $tag) {
                if (!empty($tag)) {
                    Tag::updateOrCreate(
                        ['product_id' => $product->id, 'tag_name' => $tag],
                        ['tag_name' => '#'.$tag]
                    );
                }
            }
        }
    
        // Delete tags
        $tagIds = (array) $request->input('tag-id');

        foreach ($tagIds as $tagId) {
            $hasDeleted = $request->input('tag_has_deleted_' . $tagId);
            Tag::where('id', $tagId)->update(['has_deleted' => $hasDeleted]);
        }
        
        // Update or create suppliers
        if ($request->filled('supplier_label')) {
            foreach ($request->input('supplier_label') as $index => $supplier) {
                if (!empty($supplier)) {
                    Supplier::updateOrCreate(
                        ['product_id' => $product->id, 'supplier_name' => $supplier],
                        ['supplier_name' => $supplier]
                    );
                }
            }
        }
    
        // Delete suppliers
        $supplierIds = (array) $request->input('supplier-id');
        foreach ($supplierIds as $supplierId) {
            $hasDeleted = $request->input('sup_has_deleted_' . $supplierId);
            Supplier::where('id', $supplierId)->update(['has_deleted' => $hasDeleted]);
        }

        return redirect()->route('product.listings')->with('success', 'Product Updated Successfully');
    }
    



    public function destroy($id){

        $product = Product::findOrFail($id);
        
        $product->update([
            'updated_by' => Auth::user()->id,
            'has_deleted' => 1,
        ]);

        return redirect()->route('product.listings')->withSuccess('Product Deleted Successfully');
    }
}
