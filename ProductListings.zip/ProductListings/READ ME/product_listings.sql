-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2024 at 02:10 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `product_listings`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `has_deleted` varchar(255) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `has_deleted`, `created_at`, `updated_at`) VALUES
(1, 'Men\'s Wear', '0', NULL, NULL),
(2, 'Women\'s Wear', '0', NULL, NULL),
(3, 'Kids\' Clothing', '0', NULL, NULL),
(4, 'Shoes', '0', NULL, NULL),
(5, 'Accessories', '0', NULL, NULL),
(6, 'Sportswear', '0', NULL, NULL),
(7, 'Formal Wear', '0', NULL, NULL),
(8, 'Casual Wear', '0', NULL, NULL),
(9, 'Undergarments', '0', NULL, NULL),
(10, 'Outerwear', '0', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(9, '2014_10_12_000000_create_users_table', 1),
(10, '2014_10_12_100000_create_password_resets_table', 1),
(11, '2019_08_19_000000_create_failed_jobs_table', 1),
(12, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(13, '2024_01_30_143741_create_categories_table', 1),
(14, '2024_01_30_144028_create_products_table', 1),
(17, '2024_01_30_144516_create_tags_table', 2),
(18, '2024_01_30_145030_create_suppliers_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('admin@yopmail.com', '$2y$10$jKmjx0Ab2jujhct6CReUFOvyJrLIRVC0WI4737Tsrd8tVMpTTosBS', '2024-02-02 07:35:46');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `categories` varchar(255) NOT NULL,
  `profit_amount` varchar(255) NOT NULL,
  `final_price` varchar(255) NOT NULL,
  `created_by` varchar(255) NOT NULL,
  `updated_by` varchar(255) NOT NULL,
  `has_deleted` varchar(255) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `image`, `categories`, `profit_amount`, `final_price`, `created_by`, `updated_by`, `has_deleted`, `created_at`, `updated_at`) VALUES
(1, 'Denim Dream Dress', 'The Denim Dream Dress features a flattering A-line silhouette with delicate embroidered detailing, perfect for casual outings and summer adventures.', '1000', '1706872820_images (4).jpg', '2,8', '400', '1400.00', '1', '1', '0', '2024-02-02 04:40:07', '2024-02-02 05:50:20'),
(2, 'Ethereal Whisper Dress', 'A flowing, pastel-colored chiffon dress that gracefully sways with every step, adorned with delicate lace detailing along the neckline and hem.', '2400', '1706871867_download.jpg', '2,7,8', '1600', '4000.00', '1', '1', '1', '2024-02-02 05:25:34', '2024-02-02 07:30:10'),
(3, 'Midnight Gala Gown', 'A sleek, floor-length gown crafted from midnight blue satin, featuring a plunging neckline and intricate beading along the bodice, perfect for elegant evening events.', '1300', '1706872849_download (3).jpg', '7', '1400', '2700.00', '1', '1', '0', '2024-02-02 05:36:44', '2024-02-02 05:50:49'),
(4, 'Enchanted Forest Frock', 'An enchanting forest green frock crafted from soft velvet, featuring intricate embroidery of woodland motifs and a flowing A-line silhouette reminiscent of fairy tales.', '1400', '1706874925_images (5).jpg', '2,8', '1200', '2600.00', '1', '1', '0', '2024-02-02 06:25:25', '2024-02-02 06:45:40'),
(5, 'Golden Sunset Maxi', 'A breathtaking maxi dress in warm golden hues, with a halter neckline and a cascading chiffon skirt that captures the essence of a sun-kissed evening by the shore', '1400', '1706878656_download (4).jpg', '8', '700', '2100.00', '1', '1', '0', '2024-02-02 07:27:36', '2024-02-02 07:38:57');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `supplier_name` varchar(255) NOT NULL,
  `has_deleted` varchar(255) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `product_id`, `supplier_name`, `has_deleted`, `created_at`, `updated_at`) VALUES
(1, 1, 'BlueStitch Designs', '0', '2024-02-02 04:40:07', '2024-02-02 05:50:20'),
(2, 2, 'Angelic Couture', '0', '2024-02-02 05:25:34', '2024-02-02 05:39:11'),
(3, 2, 'Serene Silhouettes', '0', '2024-02-02 05:25:34', '2024-02-02 05:39:11'),
(4, 3, 'Glamour Nights', '0', '2024-02-02 05:36:44', '2024-02-02 06:27:06'),
(5, 3, 'Starlight Elegance', '0', '2024-02-02 05:36:44', '2024-02-02 06:27:06'),
(6, 4, 'Enchanted Elegance', '0', '2024-02-02 06:25:25', '2024-02-02 07:25:53'),
(7, 4, 'Velvet Visions', '0', '2024-02-02 06:25:25', '2024-02-02 07:25:53'),
(8, 5, 'Sunlit Serenity', '0', '2024-02-02 07:27:36', '2024-02-02 07:38:57');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `tag_name` varchar(255) NOT NULL,
  `has_deleted` varchar(255) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `product_id`, `tag_name`, `has_deleted`, `created_at`, `updated_at`) VALUES
(1, 1, '#DenimDream', '0', '2024-02-02 04:40:07', '2024-02-02 05:50:20'),
(2, 1, '#CasualChic', '0', '2024-02-02 04:40:07', '2024-02-02 05:50:20'),
(3, 2, '#ethereal', '0', '2024-02-02 05:25:34', '2024-02-02 05:39:11'),
(4, 2, '#lace', '0', '2024-02-02 05:25:34', '2024-02-02 05:39:11'),
(5, 2, '#chiffon', '0', '2024-02-02 05:25:34', '2024-02-02 05:39:11'),
(6, 3, '#gala', '1', '2024-02-02 05:36:44', '2024-02-02 06:23:32'),
(7, 3, '#gown', '1', '2024-02-02 05:36:44', '2024-02-02 06:27:06'),
(8, 3, '#satin', '0', '2024-02-02 05:36:44', '2024-02-02 06:27:06'),
(9, 3, '#midnight blue', '0', '2024-02-02 05:36:44', '2024-02-02 06:27:06'),
(10, 3, '#galanew', '0', '2024-02-02 06:23:32', '2024-02-02 06:27:06'),
(11, 4, '#enchanted', '1', '2024-02-02 06:25:25', '2024-02-02 07:08:01'),
(12, 4, '#forest green', '0', '2024-02-02 06:25:25', '2024-02-02 07:25:53'),
(13, 4, '#velvet', '1', '2024-02-02 06:25:25', '2024-02-02 07:08:01'),
(14, 4, '#rare', '0', '2024-02-02 07:08:01', '2024-02-02 07:25:53'),
(15, 5, '#golden', '1', '2024-02-02 07:27:36', '2024-02-02 07:27:56'),
(16, 5, '#sunset', '0', '2024-02-02 07:27:36', '2024-02-02 07:38:57'),
(17, 5, '#halter neckline', '0', '2024-02-02 07:27:56', '2024-02-02 07:38:57');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `role` varchar(255) NOT NULL,
  `has_deleted` varchar(255) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `role`, `has_deleted`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@yopmail.com', NULL, '$2y$10$Mm2zH1sWOp/ALfKbD2KBCeUSMhj.CujAMRvPzpMgKfPMzYXOYvxlO', 'W8eaYMsSiwjJd6bnZPuFvSgAMK1Pyie29ah5xZyohcWP7lhz6SN4VXmkhZhN', 'admin', '0', '2024-02-02 02:01:40', '2024-02-02 02:01:40'),
(2, 'Customer', 'customer@yopmail.com', NULL, '$2y$10$FCfd1292httq4arC4T8khO42RnMw/uJ9jbM4RtbyW6JvKYZ47e8PG', NULL, 'customer', '0', '2024-02-02 02:02:38', '2024-02-02 02:02:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `suppliers_product_id_foreign` (`product_id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tags_product_id_foreign` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD CONSTRAINT `suppliers_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tags`
--
ALTER TABLE `tags`
  ADD CONSTRAINT `tags_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
