<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $categories = [
            ['category_name' => 'Men\'s Wear'],
            ['category_name' => 'Women\'s Wear'],
            ['category_name' => 'Kids\' Clothing'],
            ['category_name' => 'Shoes'],
            ['category_name' => 'Accessories'],
            ['category_name' => 'Sportswear'],
            ['category_name' => 'Formal Wear'],
            ['category_name' => 'Casual Wear'],
            ['category_name' => 'Undergarments'],
            ['category_name' => 'Outerwear'],
        ];
        
        Category::insert($categories);
    }
}
