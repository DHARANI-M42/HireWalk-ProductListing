$(document).ready(function () {

  $('.mobile-menu').click(function () {
    $('.main-nav').toggle('');
  })

  $('.main-nav a').click(function () {
    $('.main-nav').hide();
  })

});


// Frontend dashboard js
(function ($) {
  'use strict';
  //submenu hover
  $(document).on('mouseenter mouseleave', '.sidebar .nav-item', function (ev) {
    var body = $('body');
    var sidebarIconOnly = body.hasClass("sidebar-icon-only");
    var sidebarFixed = body.hasClass("sidebar-fixed");
    if (!('ontouchstart' in tag.tagElement)) {
      if (sidebarIconOnly) {
        if (sidebarFixed) {
          if (ev.type === 'mouseenter') {
            body.removeClass('sidebar-icon-only');
          }
        } else {
          var $menuItem = $(this);
          if (ev.type === 'mouseenter') {
            $menuItem.addClass('hover-open')
          } else {
            $menuItem.removeClass('hover-open')
          }
        }
      }
    }
  });
  $('.aside-toggler').click(function () {
    $('.chat-list-wrapper').toggleClass('slide')
  });
})(jQuery);

// sidebar scroll
$(function () {
  var body = $('body');
  var contentWrapper = $('.content-wrapper');
  var scroller = $('.container-scroller');
  var footer = $('.footer');
  var sidebar = $('.sidebar');

  //Close other submenu in sidebar on opening any

  sidebar.on('show.bs.collapse', '.collapse', function () {
    sidebar.find('.collapse.show').collapse('hide');
  });


  //Change sidebar and content-wrapper height
  applyStyles();

  function applyStyles() {
    //Applying perfect scrollbar
    if (!body.hasClass("rtl")) {
      if (body.hasClass("sidebar-fixed")) {
        var fixedSidebarScroll = new PerfectScrollbar('#sidebar .nav');
      }
    }
  }

  $('[data-toggle="minimize"]').on("click", function () {
    if ((body.hasClass('sidebar-toggle-display')) || (body.hasClass('sidebar-absolute'))) {
      body.toggleClass('sidebar-hidden');
    } else {
      body.toggleClass('sidebar-icon-only');
    }
  });


(function ($) {
  'use strict';
  $(function () {
    $('[data-toggle="offcanvas"]').on("click", function () {
      $('.sidebar-offcanvas').toggleClass('active')
    });
  });
})(jQuery);

});
// end of Frontend dashboard js


// reset Form
$('#reset-form').click(function (e) { 
e.preventDefault();

var isConfirmed = confirm("Are you sure you want to reset the form?");

if (isConfirmed) {
    
    $('form')[0].reset();
    $('.form-control, .form-select').val('');

    $('.err_msg').text('');

    $('.select2').val(null).trigger('change');

}
});


// Document Ready Function

$(document).ready(function(){


// SELECT2 MIN
$('.select2').select2();


// Date and Time flatpicker
flatpickr(".datepicker", {
dateFormat: "Y-m-d",
});

flatpickr(".datetimepicker", {
enableTime: true,
dateFormat: "Y-m-d h:i K", // 'K' for AM/PM
time_24hr: false,
});


// calculate product total price
$('.price, .profit_amount').keyup(function(){
var price = parseFloat($('.price').val());
var profit_amount = parseFloat($('.profit_amount').val());

if(isNaN(price) || isNaN(profit_amount)){
    $('.final_price').val('');
} else {
    var final_price = price + profit_amount;
    $('.final_price').val(final_price.toFixed(2));
}
});



});

function ucwords(str) {
return str.replace(/\b\w/g, function (match) {
    return match.toUpperCase();
});
}

function store(event) {
event.preventDefault();

let hasError = false;

$('.err_msg').text('');

$('input.required, textarea.required, select.required').each(function () {


    const value = $(this).val();
    const fieldName = $(this).attr('name');
    const formattedFieldName = ucwords(fieldName.replace(/[_-]/g, ' '));
    const errorMessageElement = $(`.err_msg#${fieldName.replace(/[[\]]/g, '\\$&')}`);


    if (value === '') {
        errorMessageElement.text(`${formattedFieldName} field is Required`);
        hasError = true;
    } 

      
    if (fieldName === 'categories[]') {
      const selectedCategories = $(this).val();
      if (!selectedCategories || selectedCategories.length === 0) {
          $('#categories').text(`Please select at least one category`);
          hasError = true;
      }
    }


    // Update indices and error messages for remaining elements
    updateIndices();

    $(".row.appendTags > .add_tags").each(function (index) {

        const tag_error = $("#tag-label-error-" + index);
    
        tag_error.text("");
     
        const tag = $(this)
            .find("input[name='tag_label[]']")
            .val();
        if (tag === "") {
            tag_error.text(
                "Please Include the tag name"
            );
            hasError = true;
        }

    
    });


    $(".row.appendSuppliers > .add_suppliers").each(function (index) {
      const supplier_error = $("#supplier-label-error-" + index);
  
      supplier_error.text("");
   
      const supplier = $(this)
          .find("input[name='supplier_label[]']")
          .val();
      if (supplier === "") {
          supplier_error.text(
              "Please Include the supplier name"
          );
          hasError = true;
      }
  
  });

  
});

if (!hasError) {
  $('.create_product').submit();
}

}


// Upload tags and suppliers
$(document).ready(function () {
var count = 0;

$("#add-tags").click(function () {
    count++;
    var newDiv = $(
      '<div class="col-md-6 mb-3 position-relative add_tags dynamic">' +
          '<input type="text" placeholder="Enter tag Name" id="tag-label-' +
          count +
          '" class="form-control" name="tag_label[]" maxlength="50" required>' +
          '<i class="mdi mdi-close me-2 remove-doc" title="Remove File"></i>' +
          '<span class="err_msg" id="tag-label-error-' +
          count + 
          '"></span>' +
          '</div>'
  );
  

    $(".row.appendTags").append(newDiv);

    // Dynamically bind the event handler after appending the new div
    bindRemoveTagEvent(count);

});



$("#add-suppliers").click(function () {

var sup_count = 0;
sup_count++;
var newDiv = $(
  '<div class="col-md-6 mb-3 position-relative add_suppliers dynamic">' +
      '<input type="text" placeholder="Enter supplier Name" id="supplier-label-' +
      sup_count +
      '" class="form-control" name="supplier_label[]" maxlength="50" required>' +
      '<i class="mdi mdi-close me-2 remove-doc" title="Remove File"></i>' +
      '<span class="err_msg" id="supplier-label-error-' +
      sup_count +
      '"></span>' +
      '</div>'
);

$(".row.appendSuppliers").append(newDiv);

// Dynamically bind the event handler after appending the new div
bindRemoveSupplierEvent(sup_count);
});




function bindRemoveTagEvent(count) {
    $(".row.appendTags").on(
        "click",
        "#tag-label-" + count + " + .remove-doc",
        function () {
            var result = confirm(
                "Are you sure you want to remove the tag?"
            );
            if (result) {
                // Remove the corresponding div
                $(this).closest(".add_tags").remove();

                // Update indices after removing the div
                updateIndices();
            }
        }
    );
}



function bindRemoveSupplierEvent(sup_count) {
  $(".row.appendSuppliers").on(
      "click",
      "#supplier-label-" + sup_count + " + .remove-doc",
      function () {
          var result = confirm(
              "Are you sure you want to remove the supplier?"
          );
          if (result) {
              // Remove the corresponding div
              $(this).closest(".add_suppliers").remove();

              // Update indices after removing the div
              updateIndices();
          }
      }
  );
}



});

function updateIndices() {
$(".row.appendTags > .add_tags").each(function (index) {
    const newIndex = index;
    $(this)
        .find("input, span")
        .each(function () {
            const oldId = $(this).attr("id");
            const newId = oldId.replace(/\d+/, newIndex);
            $(this).attr("id", newId);
        });
});


$(".row.appendSuppliers > .add-suppliers").each(function (index) {
  const newIndex = index;
  $(this)
      .find("input, span")
      .each(function () {
          const oldId = $(this).attr("id");
          const newId = oldId.replace(/\d+/, newIndex);
          $(this).attr("id", newId);
      });
});

}



/// Data Table Search
$(document).ready(function () {
// search inputs in footer
$("#search-data tfoot th").each(function () {
  var title = $(this).text();
  $(this).html('<input type="text" class="custom-input" placeholder="Search ' + title + '" />');
  
});


// DataTable initialisation
var table = $("#search-data").DataTable({
  paging: true,

  initComplete: function (settings, json) {
    var footer = $("#search-data tfoot tr");
    $("#search-data thead").append(footer);
  }
});

// Apply search
$("#search-data thead").on("keyup", "input", function () {
  table.column($(this).parent().index())
    .search(this.value)
    .draw();
    
});
});

// hide alert
setTimeout(function(){
$('.alert').alert('close');
}, 2000);


// EDIT PRODUCT

function update(event) {
event.preventDefault();

let hasError = false;

$('.err_msg').text('');

$('input.required, textarea.required, select.required').each(function () {
    const value = $(this).val();
    const fieldName = $(this).attr('name');
    const formattedFieldName = ucwords(fieldName.replace(/[_-]/g, ' '));
    const errorMessageElement = $(`.err_msg#${fieldName.replace(/[[\]]/g, '\\$&')}`);

    if (value === '') {
        errorMessageElement.text(`${formattedFieldName} field is Required`);
        hasError = true;
    } 

    if (fieldName === 'categories[]') {
        const selectedCategories = $(this).val();
        if (!selectedCategories || selectedCategories.length === 0) {
            $('#categories').text(`Please select at least one category`);
            hasError = true;
        }
    }
});

if (!hasError) {
    $('.create_product').submit();
}
}

// TAGS
function confirmDeleteTag(tagId) {
  if (confirm('Are you sure you want to permanently delete this tag?')) {
      document.querySelector('input[name="tag_has_deleted_' + tagId + '"]').value = 1;
      document.getElementById('remove-tag-' + tagId).classList.add('d-none');
      checkInputs(); //checkTags after deletion
  }
}

// SUPPLIERS
function confirmDeleteSupplier(supplierId) {
  if (confirm('Are you sure you want to permanently delete this supplier?')) {
      document.querySelector('input[name="sup_has_deleted_' + supplierId + '"]').value = 1;
      document.getElementById('remove-supplier-' + supplierId).classList.add('d-none');
      checkInputs(); // Check suppliers after deletion
  }
}

function checkInputs() {
  var supplierDocumentInputs = document.querySelectorAll('input[name^="sup_has_deleted_"]');
  var supplierDocUploadErrorSpan = document.getElementById('supplier-label-error-0');
  var supplierNewFileInput = document.getElementById('supplier-label-0');

  var tagDocumentInputs = document.querySelectorAll('input[name^="tag_has_deleted_"]');
  var tagDocUploadErrorSpan = document.getElementById('tag-label-error-0');
  var tagNewFileInput = document.getElementById('tag-label-0');

  var updateBtn = document.getElementById('update-btn');

  var supplierAllDeleted = true;
  var tagAllDeleted = true;

  supplierDocumentInputs.forEach(function (input) {
      if (input.value == 0) {
          supplierAllDeleted = false;
      }
  });

  tagDocumentInputs.forEach(function (input) {
      if (input.value == 0) {
          tagAllDeleted = false;
      }
  });

  if (supplierAllDeleted) {
      if (supplierNewFileInput.value.length === 0) {
          supplierDocUploadErrorSpan.textContent = "Include at least one supplier";
          updateBtn.disabled = true;
      } else {
          supplierDocUploadErrorSpan.textContent = "";
          updateBtn.disabled = false;
      }
  }

  if (tagAllDeleted) {
      if (tagNewFileInput.value.length === 0) {
          tagDocUploadErrorSpan.textContent = "Include at least one tag";
          updateBtn.disabled = true;
      } else {
          tagDocUploadErrorSpan.textContent = "";
          updateBtn.disabled = false;
      }
  }

  function updateButtonState() {
    var supplierInputLength = supplierNewFileInput.value.length;
    var tagInputLength = tagNewFileInput.value.length;


    if(tagAllDeleted){
        if(tagInputLength > 0){
          tagDocUploadErrorSpan.textContent = "";
          updateBtn.disabled = false;
        } 
        else{
          tagDocUploadErrorSpan.textContent = "Include at least one tag";
          updateBtn.disabled = true;
        }      
    }else if(supplierAllDeleted){
        if(supplierInputLength > 0){
          supplierDocUploadErrorSpan.textContent = "";
          updateBtn.disabled = false;
        }      
        else{
          supplierDocUploadErrorSpan.textContent = "Include at least one supplier";
          updateBtn.disabled = true;
        } 
    }
    

   if(supplierAllDeleted){
      if(supplierInputLength > 0){
        supplierDocUploadErrorSpan.textContent = "";
        updateBtn.disabled = false;
      }      
      else{
        supplierDocUploadErrorSpan.textContent = "Include at least one supplier";
        updateBtn.disabled = true;
      } 
    }else if(tagAllDeleted){
      if(tagInputLength > 0){
        tagDocUploadErrorSpan.textContent = "";
        updateBtn.disabled = false;
      } 
      else{
        tagDocUploadErrorSpan.textContent = "Include at least one tag";
        updateBtn.disabled = true;
      }      
    }


    if (tagAllDeleted && supplierAllDeleted){
      if (supplierInputLength === 0 || tagInputLength === 0){
        updateBtn.disabled = true;
      }else{
        updateBtn.disabled = false;
      }
    }
   

}

supplierNewFileInput.addEventListener('keyup', updateButtonState);
tagNewFileInput.addEventListener('keyup', updateButtonState);

}
