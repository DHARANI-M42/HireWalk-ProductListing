
<?php $__env->startSection('title', 'Customers Listings'); ?>
<?php $__env->startSection('body_class', ''); ?>
<?php $__env->startSection('content'); ?>

<div class="page-header">
<h3 class="page-title">
<span class="page-title-icon bg-gradient-primary text-white me-2">
<i class="mdi mdi-account-multiple"></i>
</span> Customers

</h3>


</div>



<div class="row">
<div class="col-lg-12 grid-margin stretch-card">
<div class="card">
<div class="card-body">

<?php if(count($customers) > 0): ?>

    <div class="dataTable">
    <table class="table" id="search-data">

    
        <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Registered At</th>
        </tr>
        </thead>
        <tbody>
        
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key + 1); ?></td>
                <td><?php echo e($customer->name); ?></td>
                <td><?php echo e($customer->email); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($customer->created_at)->format('M d, Y')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

        
        <tfoot>
        <!-- Individual column search -->
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Registered At</th>
        </tr>      
        </tfoot>



    </table>
    </div>

<?php else: ?>

<p class='m-0'>No Record Found</p>

<?php endif; ?>
    
</div>
</div>
</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProductListings\resources\views/customers.blade.php ENDPATH**/ ?>