
<?php $__env->startSection('title', 'Edit Product'); ?>
<?php $__env->startSection('body_class', ''); ?>
<?php $__env->startSection('content'); ?>



<div class="page-header">
    <h3 class="page-title d-flex justify-content-between w-100">
  
      
    <div class="w-100 d-md-flex justify-content-between align-items-center">
    <div>
        <span class="page-title-icon bg-gradient-primary text-white me-2">
        <i class="mdi mdi-format-list-bulleted"></i>
        </span> Edit Product
    </div>
    </div>

    <div class="action_wrap">
        <a href="<?php echo e(route('product.view', $product->id)); ?>" class="btn btn-sm btn-primary">View Product</a>
    </div> 
  
  
    </h3>
</div>
  
  
  
<form method="POST" action="<?php echo e(route('product.update', $product->id)); ?>" class='create_product' enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="card">
        <div class="row p-3 p-md-5">

            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="text"  name="name" class="form-control required" placeholder="Name" value="<?php echo e($product->name); ?>">
                    <label for="name">Name <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='name'></p>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 err_msg"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <textarea class="form-control required" placeholder="Add Description"  name="description"><?php echo e($product->description); ?></textarea>
                    <label for="description">Add Description <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='description'></p>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 err_msg"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
            </div>

            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="number"  name="price" class="form-control required price" placeholder="Price" value="<?php echo e($product->price); ?>">
                    <label for="price">Price <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='price'></p>
                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 err_msg"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>



            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="number"  name="profit_amount" class="form-control required profit_amount" placeholder="Profit Amount" value="<?php echo e($product->profit_amount); ?>">
                    <label for="profit_amount">Profit Amount <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='profit_amount'></p>
                <?php $__errorArgs = ['profit_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 err_msg"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="number" name="final_price" class="form-control required final_price" placeholder="Final Price" value="<?php echo e($product->final_price); ?>">
                    <label for="final_price">Final Price</label>
                </div>
                <?php $__errorArgs = ['final_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 err_msg"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="col-md-6 mb-4">
                <div class="form-floating d-flex">
                    <input type="file" name="image" class="form-control" placeholder="Image" value=<?php echo e($product->image); ?>>
                    <label for="image">Image <span class="text-danger ms-2">*</span></label>
                    <figure class='thumb'>
                        <img src="<?php echo e(asset('uploads/'.$product->image)); ?>" alt="">
                    </figure>
                </div>
                
                <p class='err_msg' id='image'></p>
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 err_msg"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
           

            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <select class="form-select select2 required" name='categories[]' multiple="multiple">
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($category->id); ?>" 
                                <?php if(in_array($category->id, explode(',', $product->categories))): ?> selected <?php endif; ?>>
                                <?php echo e($category->category_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option>No Record Found</option>
                        <?php endif; ?>
                    </select>
                    
                    <label for="category" class='view_point'>Choose category <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='categories'></p>
                <?php $__errorArgs = ['categories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 err_msg"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            
            <h5>Add Tags <button class="btn btn-primary btn-sm" type='button' id='add-tags'>Add More +</button></h5>
            <div class="row appendTags">
                <div class="col-md-6 mb-3 add_tags">
                    <input type="text" placeholder="Enter tag Name" id="tag-label-0" class='form-control' name='tag_label[]' maxlength="50" >
                    <span id="tag-label-error-0" class="err_msg"></span>
                </div>
            </div>


            <div class="row m-0 p-0">
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($tag->has_deleted == 0): ?>
                    <div class="col-3  mt-3" id='remove-tag-<?php echo e($tag->id); ?>'>
                      
                        <input type="hidden" name="tag-id[]" value='<?php echo e($tag->id); ?>'>
                        <input type="hidden" name="tag_has_deleted_<?php echo e($tag->id); ?>" value='<?php echo e($tag->has_deleted); ?>'>

                        <input type="hidden" name="tag_name_<?php echo e($tag->id); ?>" value='<?php echo e($tag->tag_name); ?>'>

                        <div class='d-flex align-items-center border border-1 border-dark'>
                            <p class='w-100 m-0 px-2 py-1'><?php echo e($tag->tag_name); ?></p>
                            <i class="mdi mdi-close cursor-pointer remove-file text-danger" onclick="confirmDeleteTag('<?php echo e($tag->id); ?>')"  data-toggle="tooltip" title='Delete File'></i>    
                        </div>

                    </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


            <h5 class='my-3'>Add Suppliers <button class="btn btn-primary btn-sm" type='button' id='add-suppliers'>Add More +</button></h5>
            <div class="row appendSuppliers">
                <div class="col-md-6 mb-3 add_suppliers">
                    <input type="text" placeholder="Enter supplier Name" id="supplier-label-0" class='form-control' name='supplier_label[]' maxlength="50" >
                    <span id="supplier-label-error-0" class="err_msg"></span>
                </div>
            </div>

            <div class="row m-0 p-0">
                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($supplier->has_deleted == 0): ?>
                    <div class="col-3  mt-3" id='remove-supplier-<?php echo e($supplier->id); ?>'>
                      
                        <input type="hidden" name="supplier-id[]" value='<?php echo e($supplier->id); ?>'>
                        <input type="hidden" name="sup_has_deleted_<?php echo e($supplier->id); ?>" value='<?php echo e($supplier->has_deleted); ?>'>

                        <input type="hidden" name="supplier_name_<?php echo e($supplier->id); ?>" value='<?php echo e($tag->supplier_name); ?>'>


                        <div class='d-flex align-items-center border border-1 border-dark'>
                            <p class='w-100 m-0 px-2 py-1'><?php echo e($supplier->supplier_name); ?></p>
                            <i class="mdi mdi-close cursor-pointer remove-file text-danger" onclick="confirmDeleteSupplier('<?php echo e($supplier->id); ?>')"  data-toggle="tooltip" title='Delete File'></i>    
                        </div>

                    </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            

            <div class='d-flex justify-content-end'>
                    <button class='btn btn-sm me-2 reset-button' type="button"  id="reset-form">
                        <i class='mdi mdi-reload me-1'></i> Reset
                    </button>
                <button type="button" class="submit-btn btn btn-primary mb-4 float-end" onclick="update(event)" id="update-btn">Update</button>
            </div>
            
        </div>
    </div>
</form>

<?php $__env->startSection('script'); ?>
<script>



</script>
    
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProductListings\resources\views/product/edit.blade.php ENDPATH**/ ?>