
<?php $__env->startSection('title', 'Product Detail'); ?>
<?php $__env->startSection('body_class', ''); ?>
<?php $__env->startSection('content'); ?>


<div class="page-header">
    <h3 class="page-title d-block d-md-flex justify-content-between w-100">

        <div class="breadcrumb  mb-3 mb-md-0">
          <span class="page-title-icon bg-gradient-primary text-white me-2">
              <i class="mdi mdi-eye"></i>
          </span> 
          <a href="<?php echo e(route('all.products')); ?>">Products</a>
          <span class='mx-2'>&gt;</span>
          <span class="breadcrumb-item">View</span>
          <span class="mx-2">&gt;</span>
          <span class="breadcrumb-item"><?php echo e($product->name); ?></span>
        </div>
    </h3>
</div>

<div class="col-12 grid-margin stretch-card detailed-view">
<div class="card p-3 p-md-5">

<div class="row">

    <div class="col-lg-3 d-flex justify-content-center align-items-start">
        <figure class='detail'>
            <img src="<?php echo e(asset('uploads/'.$product->image)); ?>" alt="">
        </figure>
    </div>
    <div class="col-lg-9">
        
        <div class="row mb-3">
            <label  class="col-md-3 col-form-label">Product Name</label>
            <div class="col-md-9 d-align">
                <p><?php echo e($product->name); ?></p>
            </div>
        </div>

        <div class="row mb-3">
            <label  class="col-md-3 col-form-label">Description</label>
            <div class="col-md-9 d-align">
                <p><?php echo e($product->description); ?></p>
            </div>
        </div>



        <div class="row mb-3">
            <label  class="col-md-3 col-form-label">Product Price</label>
            <div class="col-md-9 d-align">
                <p>₹ <?php echo e(number_format($product->final_price, 2)); ?></p>
            </div>
        </div>

        <?php
        $categoryIds = explode(',', $product->categories);
        $categoryNames = [];

        foreach ($categoryIds as $categoryId) {
            $category = App\Models\Category::find($categoryId);
            if ($category) {
                $categoryNames[] = $category->category_name;
            }
        }
        $tags = App\Models\Tag::where('product_id', $product->id)->where('has_deleted', '0')->get();
        $suppliers = App\Models\Supplier::where('product_id', $product->id)->where('has_deleted', '0')->get();
        ?>

        <div class="row mb-3">
            <label  class="col-md-3 col-form-label">Categories</label>
            <div class="col-md-9 d-align">
                <p>
                    <?php echo e(implode(', ', $categoryNames)); ?>

                </p>
            </div>
        </div>


        <div class="row mb-3">
            <label  class="col-md-3 col-form-label">Tags</label>
            <div class="col-md-9 d-align">
                <p>
                 <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo e($tag->tag_name); ?><?php if(!$loop->last): ?>,<?php endif; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                     No Tags Found
                 <?php endif; ?>
                </p>
            </div>
        </div>



        <div class="row mb-3">
            <label  class="col-md-3 col-form-label">Suppliers</label>
            <div class="col-md-9 d-align">
                <p>
                <?php $__empty_1 = true; $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo e($supplier->supplier_name); ?><?php if(!$loop->last): ?>,<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                     No Suppliers Found
                <?php endif; ?></p>
            </div>
        </div>


    </div>

</div>


</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProductListings\resources\views/product/customers/details.blade.php ENDPATH**/ ?>