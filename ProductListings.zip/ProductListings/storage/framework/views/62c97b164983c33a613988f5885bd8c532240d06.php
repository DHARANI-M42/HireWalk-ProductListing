<?php
$title = auth()->user()->role === 'admin' ? 'Admin Dashboard' : 'Dashboard';
?>

<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('body_class', ''); ?>
<?php $__env->startSection('content'); ?>




<div class="main-panel m-0 w-100">
    <div class="content-wrapper w-100 p-0">
          <div class="page-header">
            <h3 class="page-title">
              <span class="page-title-icon bg-gradient-primary text-white me-2">
                <i class="mdi  mdi-chart-line menu-icon"></i>
              </span> Dashboard
            </h3>
            <nav aria-label="breadcrumb">
              <ul class="breadcrumb d-none">
                <li class="breadcrumb-item active" aria-current="page">
                  <span></span>Overview <i class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                </li>
              </ul>
            </nav>
          </div>
    
        <div class="row dashboard-cards">

            <?php if(Auth::user()->role == 'admin'): ?>

            <div class="col-md-6 col-xl-4 stretch-card grid-margin">
            <div class="card bg-gradient-success card-img-holder">
                <a href="<?php echo e(route('product.listings')); ?>" class='text-white'>
                <div class="card-body">
                    <h4 class="font-weight-normal mb-3">Listings <i
                        class="mdi mdi-lead-pencil mdi-24px float-right"></i>
                    </h4>
                    <h2 class=""><?php echo e($total_products); ?></h2>
                </div>
                </a>
            </div>
            </div>

            <div class="col-md-6 col-xl-4 stretch-card grid-margin">
                <div class="card bg-gradient-success card-img-holder">
                    <a href="<?php echo e(route('customers.index')); ?>"  class='text-white'>
                    <div class="card-body">
                        <h4 class="font-weight-normal mb-3">Active Customers <i
                            class="mdi mdi-account-multiple mdi-24px float-right"></i>
                        </h4>
                        <h2 class=""><?php echo e($total_customers); ?></h2>
                    </div>
                    </a>
                </div>
            </div>

            <?php else: ?>

            <div class="col-md-6 col-xl-4 stretch-card grid-margin">
                <div class="card bg-gradient-success card-img-holder">
                    <a href="<?php echo e(route('all.products')); ?>" class='text-white'>
                    <div class="card-body">
                        <h4 class="font-weight-normal mb-3">Active Products <i
                            class="mdi mdi-cart mdi-24px float-right"></i>
                        </h4>
                        <h2 class=""><?php echo e($total_products); ?></h2>
                    </div>
                    </a>
                </div>
            </div>

            <?php endif; ?>



        </div>
    
    </div>
    </div>











<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProductListings\resources\views/home.blade.php ENDPATH**/ ?>