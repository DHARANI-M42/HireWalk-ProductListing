
<?php $__env->startSection('title', 'Product Listings'); ?>
<?php $__env->startSection('body_class', ''); ?>
<?php $__env->startSection('content'); ?>

<div class="page-header">
<h3 class="page-title">
<span class="page-title-icon bg-gradient-primary text-white me-2">
<i class="mdi mdi-cart"></i>
</span> Products

<a href="<?php echo e(route('product.create')); ?>" class='btn btn-primary float-end'>Add Product</a>
</h3>


</div>



<div class="modal fade p-0" id="deleteproduct" tabindex="-1" aria-labelledby="deleteproduct" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5 text-danger">Delete Product</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="m-0">Are you sure you want to delete this product?</p>
            </div>
            <div class="modal-footer modal-btns">
                <input type="hidden" name="product_id" id='product_id'>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <form action="" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Yes, Delete</button>
              </form>
            </div>
        </div>
    </div>
</div>
  


<div class="row">
<div class="col-lg-12 grid-margin stretch-card">
<div class="card">
<div class="card-body">

<?php if(count($products) > 0): ?>

    <div class="dataTable">
    <table class="table" id="search-data">

    
        <thead>
        <tr>
            <th>#</th>
            <th>Product Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Profit</th>
            <th>Total</th>
            <th>Categories</th>
            <th>Suppliers</th>
            <th>Tags</th>
            <th>Created By</th>
            <th>Updated By</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($key + 1); ?></td>
            <td><a href="<?php echo e(route('product.view', $product->id)); ?>"><?php echo e($product->name); ?></a></td>
            <td><?php echo e($product->description); ?></td>
            <td>₹ <?php echo e(number_format($product->price, 2)); ?></td>
            <td>₹ <?php echo e(number_format($product->profit_amount, 2)); ?></td>
            <td>₹ <?php echo e(number_format($product->final_price, 2)); ?></td>


            <?php
                $categoryIds = explode(',', $product->categories);
                $categoryNames = [];
        
                foreach ($categoryIds as $categoryId) {
                    $category = App\Models\Category::find($categoryId);
                    if ($category) {
                        $categoryNames[] = $category->category_name;
                    }
                }
        
                $tags = App\Models\Tag::where('product_id', $product->id)->where('has_deleted', '0')->get();
                $suppliers = App\Models\Supplier::where('product_id', $product->id)->where('has_deleted', '0')->get();
            ?>

            <td>
                <?php echo e(implode(', ', $categoryNames)); ?>

            </td>

            <td>
                <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                   <?php echo e($tag->tag_name); ?><?php if(!$loop->last): ?>,<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    No Tags Found
                <?php endif; ?>
            </td>

            <td>
                <?php $__empty_1 = true; $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                   <?php echo e($supplier->supplier_name); ?><?php if(!$loop->last): ?>,<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    No Suppliers Found
                <?php endif; ?>
            </td>

            <td><?php echo e($product->createdBy->name); ?></td>
            <td><?php echo e($product->updatedBy->name); ?></td>
            

            <td>
                <div class='action_icons'>
                    <a href="<?php echo e(route('product.view', $product->id)); ?>" target="_blank"><i class='mdi mdi-eye me-2'></i></a>
                    <a href="<?php echo e(route('product.edit', $product->id)); ?>" ><i class='mdi mdi-lead-pencil me-2'></i></a>
                    
                    <a class="border-0 bg-transparent delete_product" data-bs-toggle="modal" data-bs-target="#deleteproduct" data-bs-value="<?php echo e($product->id); ?>">
                      <i class="mdi mdi-delete"></i>
                    </a>
                </div>
            </td>


        </tr>

  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
     

        </tbody>

        
        <tfoot>
        <!-- Individual column search -->
        <tr>
            <th>#</th>
            <th>Product Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Profit</th>
            <th>Total</th>
            <th>Tags</th>
            <th>Suppliers</th>
            <th>Created By</th>
            <th>Updated By</th>
            <th></th>
        </tr>      
        </tfoot>



    </table>
    </div>

<?php else: ?>

<p class='m-0'>No Record Found</p>

<?php endif; ?>
    
</div>
</div>
</div>

</div>


<?php $__env->startSection('script'); ?>
<script>

$('.delete_product').click(function (e) { 
    e.preventDefault();
    var product_id = $(this).data('bs-value');
    $('#product_id').val(product_id);
    var deleteUrl = "<?php echo e(route('product.destroy', ['id' => '_product_ID__'])); ?>";
    deleteUrl = deleteUrl.replace('_product_ID__', product_id);
    $('#deleteproduct form').attr('action', deleteUrl);
});


</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProductListings\resources\views/product/listings.blade.php ENDPATH**/ ?>