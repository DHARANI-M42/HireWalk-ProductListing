
<?php $__env->startSection('title', 'All Products'); ?>
<?php $__env->startSection('body_class', 'all_products'); ?>
<?php $__env->startSection('content'); ?>

<div class="page-header">
<h3 class="page-title">
<span class="page-title-icon bg-gradient-primary text-white me-2">
<i class="mdi mdi-cart"></i>
</span> Products

</div>


<div class="row">

  
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

 


    <div class="main col-md-4 col-lg-3">

      <a href="<?php echo e(route('product.detail', $product->id)); ?>">
        <ul class="cards">
          <li class="cards_item">
            <div class="card">
              <div class="card_image"><img src="<?php echo e(asset('uploads/'.$product->image)); ?>"></div>
              <div class="card_content">
                <h2 class="card_title mb-3"><?php echo e($product->name); ?></h2>
                <p class="card_text desc"><?php echo e($product->description); ?></p>
                <p class="card_text"><b>₹ <?php echo e(number_format($product->price, 2)); ?></b></p>
                <a href="<?php echo e(route('product.detail', $product->id)); ?>"  class="btn card_btn">View</a>
              </div>
            </div>
          </li>
        </a>
      </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <p class='m-0'>No Products Found</p>
    <?php endif; ?>

</div>

  



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProductListings\resources\views/product/customers/allproducts.blade.php ENDPATH**/ ?>