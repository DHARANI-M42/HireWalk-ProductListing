
<?php $__env->startSection('title', 'Create Product'); ?>
<?php $__env->startSection('body_class', ''); ?>
<?php $__env->startSection('content'); ?>



<div class="page-header">
    <h3 class="page-title d-flex justify-content-between w-100">
      
      <div class="w-100 d-md-flex justify-content-between align-items-center">
        <div>
          <span class="page-title-icon bg-gradient-primary text-white me-2">
            <i class="mdi mdi-format-list-bulleted"></i>
          </span> Create Product
        </div>

        <a href="<?php echo e(route('product.listings')); ?>" class='btn btn-primary float-end'>View Products</a>
  
      </div>
  
    </h3>
</div>
  
  
  
<form method="POST" action="<?php echo e(route('product.store')); ?>" class='create_product' enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="card">
        <div class="row p-3 p-md-5">

            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="text"  name="name" class="form-control required" placeholder="Name" value="<?php echo e(old('name')); ?>">
                    <label for="name">Name <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='name'></p>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 err_msg"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <textarea class="form-control required" placeholder="Add Description"  name="description"><?php echo e(old('description')); ?></textarea>
                    <label for="description">Add Description <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='description'></p>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 err_msg"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
            </div>

            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="number"  name="price" class="form-control required price" placeholder="Price" value="<?php echo e(old('price')); ?>">
                    <label for="price">Price <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='price'></p>
                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 err_msg"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>



            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="number"  name="profit_amount" class="form-control required profit_amount" placeholder="Profit Amount" value="<?php echo e(old('profit_amount')); ?>">
                    <label for="profit_amount">Profit Amount <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='profit_amount'></p>
                <?php $__errorArgs = ['profit_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 err_msg"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="number" name="final_price" class="form-control required final_price" placeholder="Final Price" value="<?php echo e(old('final_price')); ?>">
                    <label for="final_price">Final Price</label>
                </div>
                <?php $__errorArgs = ['final_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 err_msg"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="file" name="image" class="form-control required" placeholder="Image">
                    <label for="image">Image <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='image'></p>
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 err_msg"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <select class="form-select select2 required" name='categories[]' multiple="multiple">
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($category->id); ?>" 
                                <?php echo e((is_array(old('categories')) && in_array($category->id, old('categories'))) ? 'selected' : ''); ?>>
                                <?php echo e($category->category_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option>No Record Found</option>
                        <?php endif; ?>
                    </select>
                    
                    <label for="category" class='view_point'>Choose category <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='categories'></p>
                <?php $__errorArgs = ['categories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 err_msg"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            


            <h5>Add Tags <button class="btn btn-primary btn-sm" type='button' id='add-tags'>Add More +</button></h5>
            <div class="row appendTags">
                <div class="col-md-6 mb-3 add_tags">
                    <input type="text" placeholder="Enter tag Name" id="tag-label-0" class='form-control' name='tag_label[]' maxlength="50" >
                    <span id="tag-label-error-0" class="err_msg"></span>
                </div>
            </div>


            <h5 class='my-3'>Add Suppliers <button class="btn btn-primary btn-sm" type='button' id='add-suppliers'>Add More +</button></h5>
            <div class="row appendSuppliers">
                <div class="col-md-6 mb-3 add_suppliers">
                    <input type="text" placeholder="Enter supplier Name" id="supplier-label-0" class='form-control' name='supplier_label[]' maxlength="50" >
                    <span id="supplier-label-error-0" class="err_msg"></span>
                </div>
            </div>
            

            <div class='d-flex justify-content-end'>
                    <button class='btn btn-sm me-2 reset-button' type="button"  id="reset-form">
                        <i class='mdi mdi-reload me-1'></i> Reset
                    </button>
                <button type="button" class="submit-btn btn btn-primary mb-4 float-end" onclick="store(event)">Create</button>
            </div>
            

        </div>
    </div>
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProductListings\resources\views/product/create.blade.php ENDPATH**/ ?>