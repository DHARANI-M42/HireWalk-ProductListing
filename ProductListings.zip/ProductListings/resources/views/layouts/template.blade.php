<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>@yield('title') | ProductListing</title>

    <!-- Styles -->
    <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/materialdesignicons.min.css') }}"  rel="stylesheet">
    <link href="{{asset('css/select2.min.css')}}" rel="stylesheet">
    <link href="{{asset('css/flatpickr.min.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
    <link href="{{ asset('css/theme.css') }}" rel="stylesheet">

</head>
<body class='@yield("body_class")'>


    <div class="container-scroller">

        <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row w-100">

            <div class="navbar-menu-wrapper d-flex align-items-stretch w-100">

                <header id="mainNav" class='w-100 hedaer_nav'>
                    <div class="mobile-menu">
                        <i></i>
                    </div>
                    <nav class="navbar">
                        <div class="top-left">
                            <a href="" class="navbar-brand m-0">
                               Ecom
                            </a>
                        </div>

                        <div class='top-right'>
               
                            <div class="dropdown show">
                                <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                {{ Auth::user()->name }}
                                </a>

                                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <a class="dropdown-item" href="{{ route('dashboard') }}">Dashboard</a>
                                  
                                        <a class="dropdown-item" href="{{ route('logout') }}"
                                           onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>
    
                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                            @csrf
                                        </form>
                                    
                                </div>
                            
                            </div>
                        </div>
                      
                       
                        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
                            data-toggle="offcanvas">
                            <span class="mdi mdi-menu"></span>
                        </button>
                    </nav>

                </header>
            </div>
        </nav>


        <div class="container-fluid page-body-wrapper">
            <!-- sidebar -->
            <nav class="sidebar sidebar-offcanvas" id="sidebar">
                <ul class="nav">


                    <li class="nav-item">
                        <a class="nav-link {{ (url()->current() == route('dashboard')) ? 'active' : 'none' }}" href="{{ route('dashboard') }}">
                            <span class="menu-title">Dashboard</span>
                            <i class="mdi mdi-chart-line menu-icon"></i>
                        </a>
                    </li>


                    @php
                    $product_menu = (request()->routeIs('product.listings') || request()->routeIs('product.edit'));
                    @endphp

                    @if(Auth::user()->role == 'admin')
                    <li class="nav-item">
                        <a class="nav-link {{ (url()->current() == route('product.create')) ? 'active' : 'none' }}" href="{{ route('product.create') }}">
                            <span class="menu-title">Add Products</span>
                            <i class="mdi mdi-plus menu-icon"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{$product_menu ? 'active' : 'none'}}" href="{{ route('product.listings') }}">
                            <span class="menu-title">Listings</span>
                            <i class="mdi mdi-lead-pencil menu-icon"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{url()->current() == route('customers.index') ? 'active' : 'none'}}" href="{{ route('customers.index') }}">
                            <span class="menu-title">Customers</span>
                            <i class="mdi mdi-account-multiple menu-icon"></i>
                        </a>
                    </li>
                    @endif

                    <li class="nav-item">
                        <a class="nav-link {{ (url()->current() == route('all.products')) ? 'active' : 'none' }}" href="{{ route('all.products') }}">
                            <span class="menu-title">Products</span>
                            <i class="mdi mdi-cart menu-icon"></i>
                        </a>
                    </li>


                </ul>
            </nav>

            <div class="main-panel">
                <div class="content-wrapper">

                    @if (session('success'))
                    <div class="alert alert-success alert-dismissible fade show global-alert" role="alert">
                        <p class='m-0'>{{ session('success') }}</p>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"
                            aria-label="Close"></button>
                    </div>
                    @endif

                    @if (session('message'))
                    <div class="alert alert-info alert-dismissible fade show global-alert" role="alert">
                        <p class='m-0'>{{ session('message') }}</p>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"
                            aria-label="Close"></button>
                    </div>
                    @endif

                    @if (session('error'))
                    <div class="alert alert-danger alert-dismissible fade show global-alert" role="alert">
                        <p class='m-0'>{{ session('error') }}</p>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"
                            aria-label="Close"></button>
                    </div>
                    @endif


                    @yield('content')
                </div>

                <!-- footer-->
                <footer class="footer">
                    <div class="container-fluid d-flex justify-content-center">
                        <span class="text-muted">Copyright © 2024 ProductListing. All rights Reserved.</span>
                    </div>
                </footer>

            </div>



        </div>

    </div>




      <!-- Scripts -->
      <script src="{{ asset('js/jquery-3.7.1.min.js') }}" ></script>
      <script src="{{ asset('js/bootstrap.bundle.min.js') }}" ></script>
      <script src="{{ asset('js/select2.min.js') }}"></script>
      <script src="{{ asset('js/flatpickr.min.js') }}"></script>
      <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
      <script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
      <script src="{{ asset('js/custom.js') }}" ></script>

      @yield('script')
      
</body>
</html>
