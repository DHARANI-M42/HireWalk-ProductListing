@extends('layouts.template')
@section('title', 'Edit Product')
@section('body_class', '')
@section('content')



<div class="page-header">
    <h3 class="page-title d-flex justify-content-between w-100">
  
      
    <div class="w-100 d-md-flex justify-content-between align-items-center">
    <div>
        <span class="page-title-icon bg-gradient-primary text-white me-2">
        <i class="mdi mdi-format-list-bulleted"></i>
        </span> Edit Product
    </div>
    </div>

    <div class="action_wrap">
        <a href="{{ route('product.view', $product->id) }}" class="btn btn-sm btn-primary">View Product</a>
    </div> 
  
  
    </h3>
</div>
  
  
  
<form method="POST" action="{{route('product.update', $product->id)}}" class='create_product' enctype="multipart/form-data">
    @csrf
    @method('PUT')
    <div class="card">
        <div class="row p-3 p-md-5">

            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="text"  name="name" class="form-control required" placeholder="Name" value="{{$product->name}}">
                    <label for="name">Name <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='name'></p>
                @error('name')
                <p class="mt-2 err_msg">{{ $message }}</p>
                @enderror
            </div>


            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <textarea class="form-control required" placeholder="Add Description"  name="description">{{ $product->description}}</textarea>
                    <label for="description">Add Description <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='description'></p>
                @error('description')
                <p class="mt-2 err_msg">{{ $message }}</p>
                @enderror 
            </div>

            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="number"  name="price" class="form-control required price" placeholder="Price" value="{{$product->price}}">
                    <label for="price">Price <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='price'></p>
                @error('price')
                <p class="mt-2 err_msg">{{ $message }}</p>
                @enderror
            </div>



            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="number"  name="profit_amount" class="form-control required profit_amount" placeholder="Profit Amount" value="{{$product->profit_amount}}">
                    <label for="profit_amount">Profit Amount <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='profit_amount'></p>
                @error('profit_amount')
                <p class="mt-2 err_msg">{{ $message }}</p>
                @enderror
            </div>


            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="number" name="final_price" class="form-control required final_price" placeholder="Final Price" value="{{$product->final_price}}">
                    <label for="final_price">Final Price</label>
                </div>
                @error('final_price')
                <p class="mt-2 err_msg">{{ $message }}</p>
                @enderror
            </div>


            <div class="col-md-6 mb-4">
                <div class="form-floating d-flex">
                    <input type="file" name="image" class="form-control" placeholder="Image" value={{$product->image}}>
                    <label for="image">Image <span class="text-danger ms-2">*</span></label>
                    <figure class='thumb'>
                        <img src="{{ asset('uploads/'.$product->image) }}" alt="">
                    </figure>
                </div>
                
                <p class='err_msg' id='image'></p>
                @error('image')
                <p class="mt-2 err_msg">{{ $message }}</p>
                @enderror
            </div>
           

            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <select class="form-select select2 required" name='categories[]' multiple="multiple">
                        @forelse ($categories as $category)
                            <option value="{{ $category->id }}" 
                                @if(in_array($category->id, explode(',', $product->categories))) selected @endif>
                                {{ $category->category_name }}
                            </option>
                        @empty
                            <option>No Record Found</option>
                        @endforelse
                    </select>
                    
                    <label for="category" class='view_point'>Choose category <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='categories'></p>
                @error('categories')
                <p class="mt-2 err_msg">{{ $message }}</p>
                @enderror
            </div>
            
            
            <h5>Add Tags <button class="btn btn-primary btn-sm" type='button' id='add-tags'>Add More +</button></h5>
            <div class="row appendTags">
                <div class="col-md-6 mb-3 add_tags">
                    <input type="text" placeholder="Enter tag Name" id="tag-label-0" class='form-control' name='tag_label[]' maxlength="50" >
                    <span id="tag-label-error-0" class="err_msg"></span>
                </div>
            </div>


            <div class="row m-0 p-0">
                @foreach($tags as $tag)
                @if($tag->has_deleted == 0)
                    <div class="col-3  mt-3" id='remove-tag-{{ $tag->id }}'>
                      
                        <input type="hidden" name="tag-id[]" value='{{ $tag->id}}'>
                        <input type="hidden" name="tag_has_deleted_{{ $tag->id }}" value='{{ $tag->has_deleted}}'>

                        <input type="hidden" name="tag_name_{{ $tag->id }}" value='{{ $tag->tag_name }}'>

                        <div class='d-flex align-items-center border border-1 border-dark'>
                            <p class='w-100 m-0 px-2 py-1'>{{ $tag->tag_name }}</p>
                            <i class="mdi mdi-close cursor-pointer remove-file text-danger" onclick="confirmDeleteTag('{{ $tag->id }}')"  data-toggle="tooltip" title='Delete File'></i>    
                        </div>

                    </div>
                @endif
                @endforeach
            </div>


            <h5 class='my-3'>Add Suppliers <button class="btn btn-primary btn-sm" type='button' id='add-suppliers'>Add More +</button></h5>
            <div class="row appendSuppliers">
                <div class="col-md-6 mb-3 add_suppliers">
                    <input type="text" placeholder="Enter supplier Name" id="supplier-label-0" class='form-control' name='supplier_label[]' maxlength="50" >
                    <span id="supplier-label-error-0" class="err_msg"></span>
                </div>
            </div>

            <div class="row m-0 p-0">
                @foreach($suppliers as $supplier)
                @if($supplier->has_deleted == 0)
                    <div class="col-3  mt-3" id='remove-supplier-{{ $supplier->id }}'>
                      
                        <input type="hidden" name="supplier-id[]" value='{{ $supplier->id}}'>
                        <input type="hidden" name="sup_has_deleted_{{ $supplier->id }}" value='{{ $supplier->has_deleted}}'>

                        <input type="hidden" name="supplier_name_{{ $supplier->id }}" value='{{ $tag->supplier_name }}'>


                        <div class='d-flex align-items-center border border-1 border-dark'>
                            <p class='w-100 m-0 px-2 py-1'>{{ $supplier->supplier_name }}</p>
                            <i class="mdi mdi-close cursor-pointer remove-file text-danger" onclick="confirmDeleteSupplier('{{ $supplier->id }}')"  data-toggle="tooltip" title='Delete File'></i>    
                        </div>

                    </div>
                @endif
                @endforeach
            </div>

            

            <div class='d-flex justify-content-end'>
                    <button class='btn btn-sm me-2 reset-button' type="button"  id="reset-form">
                        <i class='mdi mdi-reload me-1'></i> Reset
                    </button>
                <button type="button" class="submit-btn btn btn-primary mb-4 float-end" onclick="update(event)" id="update-btn">Update</button>
            </div>
            
        </div>
    </div>
</form>

@section('script')
<script>



</script>
    
@endsection

@endsection