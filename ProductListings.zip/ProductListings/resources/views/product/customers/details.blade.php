@extends('layouts.template')
@section('title', 'Product Detail')
@section('body_class', '')
@section('content')


<div class="page-header">
    <h3 class="page-title d-block d-md-flex justify-content-between w-100">

        <div class="breadcrumb  mb-3 mb-md-0">
          <span class="page-title-icon bg-gradient-primary text-white me-2">
              <i class="mdi mdi-eye"></i>
          </span> 
          <a href="{{ route('all.products') }}">Products</a>
          <span class='mx-2'>&gt;</span>
          <span class="breadcrumb-item">View</span>
          <span class="mx-2">&gt;</span>
          <span class="breadcrumb-item">{{ $product->name }}</span>
        </div>
    </h3>
</div>

<div class="col-12 grid-margin stretch-card detailed-view">
<div class="card p-3 p-md-5">

<div class="row">

    <div class="col-lg-3 d-flex justify-content-center align-items-start">
        <figure class='detail'>
            <img src="{{ asset('uploads/'.$product->image) }}" alt="">
        </figure>
    </div>
    <div class="col-lg-9">
        
        <div class="row mb-3">
            <label  class="col-md-3 col-form-label">Product Name</label>
            <div class="col-md-9 d-align">
                <p>{{ $product->name }}</p>
            </div>
        </div>

        <div class="row mb-3">
            <label  class="col-md-3 col-form-label">Description</label>
            <div class="col-md-9 d-align">
                <p>{{ $product->description }}</p>
            </div>
        </div>



        <div class="row mb-3">
            <label  class="col-md-3 col-form-label">Product Price</label>
            <div class="col-md-9 d-align">
                <p>₹ {{ number_format($product->final_price, 2) }}</p>
            </div>
        </div>

        @php
        $categoryIds = explode(',', $product->categories);
        $categoryNames = [];

        foreach ($categoryIds as $categoryId) {
            $category = App\Models\Category::find($categoryId);
            if ($category) {
                $categoryNames[] = $category->category_name;
            }
        }
        $tags = App\Models\Tag::where('product_id', $product->id)->where('has_deleted', '0')->get();
        $suppliers = App\Models\Supplier::where('product_id', $product->id)->where('has_deleted', '0')->get();
        @endphp

        <div class="row mb-3">
            <label  class="col-md-3 col-form-label">Categories</label>
            <div class="col-md-9 d-align">
                <p>
                    {{ implode(', ', $categoryNames) }}
                </p>
            </div>
        </div>


        <div class="row mb-3">
            <label  class="col-md-3 col-form-label">Tags</label>
            <div class="col-md-9 d-align">
                <p>
                 @forelse ($tags as $tag)
                    {{ $tag->tag_name}}@if(!$loop->last),@endif
                 @empty
                     No Tags Found
                 @endforelse
                </p>
            </div>
        </div>



        <div class="row mb-3">
            <label  class="col-md-3 col-form-label">Suppliers</label>
            <div class="col-md-9 d-align">
                <p>
                @forelse ($suppliers as $supplier)
                    {{ $supplier->supplier_name}}@if(!$loop->last),@endif
                @empty
                     No Suppliers Found
                @endforelse</p>
            </div>
        </div>


    </div>

</div>


</div>
</div>


@endsection