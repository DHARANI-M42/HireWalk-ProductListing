@extends('layouts.template')
@section('title', 'All Products')
@section('body_class', 'all_products')
@section('content')

<div class="page-header">
<h3 class="page-title">
<span class="page-title-icon bg-gradient-primary text-white me-2">
<i class="mdi mdi-cart"></i>
</span> Products

</div>


<div class="row">

  
    @forelse ($products as $key => $product)

 


    <div class="main col-md-4 col-lg-3">

      <a href="{{ route('product.detail', $product->id) }}">
        <ul class="cards">
          <li class="cards_item">
            <div class="card">
              <div class="card_image"><img src="{{ asset('uploads/'.$product->image) }}"></div>
              <div class="card_content">
                <h2 class="card_title mb-3">{{ $product->name }}</h2>
                <p class="card_text desc">{{ $product->description }}</p>
                <p class="card_text"><b>₹ {{ number_format($product->price, 2) }}</b></p>
                <a href="{{ route('product.detail', $product->id) }}"  class="btn card_btn">View</a>
              </div>
            </div>
          </li>
        </a>
      </div>

    @empty
      <p class='m-0'>No Products Found</p>
    @endforelse

</div>

  



@endsection