@extends('layouts.template')
@section('title', 'Product Listings')
@section('body_class', '')
@section('content')

<div class="page-header">
<h3 class="page-title">
<span class="page-title-icon bg-gradient-primary text-white me-2">
<i class="mdi mdi-cart"></i>
</span> Products

<a href="{{ route('product.create') }}" class='btn btn-primary float-end'>Add Product</a>
</h3>


</div>


{{-- delete product modal--}}
<div class="modal fade p-0" id="deleteproduct" tabindex="-1" aria-labelledby="deleteproduct" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5 text-danger">Delete Product</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="m-0">Are you sure you want to delete this product?</p>
            </div>
            <div class="modal-footer modal-btns">
                <input type="hidden" name="product_id" id='product_id'>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <form action="" method="POST">
                  @csrf
                  @method('DELETE')
                <button type="submit" class="btn btn-danger">Yes, Delete</button>
              </form>
            </div>
        </div>
    </div>
</div>
  
{{-- end of delete product modal --}}

<div class="row">
<div class="col-lg-12 grid-margin stretch-card">
<div class="card">
<div class="card-body">

@if(count($products) > 0)

    <div class="dataTable">
    <table class="table" id="search-data">

    
        <thead>
        <tr>
            <th>#</th>
            <th>Product Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Profit</th>
            <th>Total</th>
            <th>Categories</th>
            <th>Suppliers</th>
            <th>Tags</th>
            <th>Created By</th>
            <th>Updated By</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        

        @foreach ($products as $key => $product)
        <tr>
            <td>{{ $key + 1 }}</td>
            <td><a href="{{ route('product.view', $product->id) }}">{{ $product->name }}</a></td>
            <td>{{ $product->description }}</td>
            <td>₹ {{ number_format($product->price, 2) }}</td>
            <td>₹ {{ number_format($product->profit_amount, 2) }}</td>
            <td>₹ {{ number_format($product->final_price, 2) }}</td>


            @php
                $categoryIds = explode(',', $product->categories);
                $categoryNames = [];
        
                foreach ($categoryIds as $categoryId) {
                    $category = App\Models\Category::find($categoryId);
                    if ($category) {
                        $categoryNames[] = $category->category_name;
                    }
                }
        
                $tags = App\Models\Tag::where('product_id', $product->id)->where('has_deleted', '0')->get();
                $suppliers = App\Models\Supplier::where('product_id', $product->id)->where('has_deleted', '0')->get();
            @endphp

            <td>
                {{ implode(', ', $categoryNames) }}
            </td>

            <td>
                @forelse ($tags as $tag)
                   {{ $tag->tag_name}}@if(!$loop->last),@endif
                @empty
                    No Tags Found
                @endforelse
            </td>

            <td>
                @forelse ($suppliers as $supplier)
                   {{ $supplier->supplier_name}}@if(!$loop->last),@endif
                @empty
                    No Suppliers Found
                @endforelse
            </td>

            <td>{{ $product->createdBy->name }}</td>
            <td>{{ $product->updatedBy->name }}</td>
            

            <td>
                <div class='action_icons'>
                    <a href="{{ route('product.view', $product->id) }}" target="_blank"><i class='mdi mdi-eye me-2'></i></a>
                    <a href="{{ route('product.edit', $product->id) }}" ><i class='mdi mdi-lead-pencil me-2'></i></a>
                    
                    <a class="border-0 bg-transparent delete_product" data-bs-toggle="modal" data-bs-target="#deleteproduct" data-bs-value="{{ $product->id }}">
                      <i class="mdi mdi-delete"></i>
                    </a>
                </div>
            </td>


        </tr>

  
        @endforeach

            
     

        </tbody>

        
        <tfoot>
        <!-- Individual column search -->
        <tr>
            <th>#</th>
            <th>Product Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Profit</th>
            <th>Total</th>
            <th>Tags</th>
            <th>Suppliers</th>
            <th>Created By</th>
            <th>Updated By</th>
            <th></th>
        </tr>      
        </tfoot>



    </table>
    </div>

@else

<p class='m-0'>No Record Found</p>

@endif
    
</div>
</div>
</div>

</div>


@section('script')
<script>

$('.delete_product').click(function (e) { 
    e.preventDefault();
    var product_id = $(this).data('bs-value');
    $('#product_id').val(product_id);
    var deleteUrl = "{{ route('product.destroy', ['id' => '_product_ID__']) }}";
    deleteUrl = deleteUrl.replace('_product_ID__', product_id);
    $('#deleteproduct form').attr('action', deleteUrl);
});


</script>
@endsection

@endsection