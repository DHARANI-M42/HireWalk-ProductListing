@extends('layouts.template')
@section('title', 'Create Product')
@section('body_class', '')
@section('content')



<div class="page-header">
    <h3 class="page-title d-flex justify-content-between w-100">
      
      <div class="w-100 d-md-flex justify-content-between align-items-center">
        <div>
          <span class="page-title-icon bg-gradient-primary text-white me-2">
            <i class="mdi mdi-format-list-bulleted"></i>
          </span> Create Product
        </div>

        <a href="{{ route('product.listings') }}" class='btn btn-primary float-end'>View Products</a>
  
      </div>
  
    </h3>
</div>
  
  
  
<form method="POST" action="{{route('product.store')}}" class='create_product' enctype="multipart/form-data">
    @csrf
    <div class="card">
        <div class="row p-3 p-md-5">

            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="text"  name="name" class="form-control required" placeholder="Name" value="{{old('name')}}">
                    <label for="name">Name <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='name'></p>
                @error('name')
                <p class="mt-2 err_msg">{{ $message }}</p>
                @enderror
            </div>


            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <textarea class="form-control required" placeholder="Add Description"  name="description">{{ old('description') }}</textarea>
                    <label for="description">Add Description <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='description'></p>
                @error('description')
                <p class="mt-2 err_msg">{{ $message }}</p>
                @enderror 
            </div>

            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="number"  name="price" class="form-control required price" placeholder="Price" value="{{old('price')}}">
                    <label for="price">Price <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='price'></p>
                @error('price')
                <p class="mt-2 err_msg">{{ $message }}</p>
                @enderror
            </div>



            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="number"  name="profit_amount" class="form-control required profit_amount" placeholder="Profit Amount" value="{{old('profit_amount')}}">
                    <label for="profit_amount">Profit Amount <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='profit_amount'></p>
                @error('profit_amount')
                <p class="mt-2 err_msg">{{ $message }}</p>
                @enderror
            </div>


            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="number" name="final_price" class="form-control required final_price" placeholder="Final Price" value="{{old('final_price')}}">
                    <label for="final_price">Final Price</label>
                </div>
                @error('final_price')
                <p class="mt-2 err_msg">{{ $message }}</p>
                @enderror
            </div>


            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <input type="file" name="image" class="form-control required" placeholder="Image">
                    <label for="image">Image <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='image'></p>
                @error('image')
                <p class="mt-2 err_msg">{{ $message }}</p>
                @enderror
            </div>


            <div class="col-md-6 mb-4">
                <div class="form-floating">
                    <select class="form-select select2 required" name='categories[]' multiple="multiple">
                        @forelse ($categories as $category)
                            <option value="{{ $category->id }}" 
                                {{ (is_array(old('categories')) && in_array($category->id, old('categories'))) ? 'selected' : '' }}>
                                {{ $category->category_name }}
                            </option>
                        @empty
                            <option>No Record Found</option>
                        @endforelse
                    </select>
                    
                    <label for="category" class='view_point'>Choose category <span class="text-danger ms-2">*</span></label>
                </div>
                <p class='err_msg' id='categories'></p>
                @error('categories')
                <p class="mt-2 err_msg">{{ $message }}</p>
                @enderror
            </div>
            


            <h5>Add Tags <button class="btn btn-primary btn-sm" type='button' id='add-tags'>Add More +</button></h5>
            <div class="row appendTags">
                <div class="col-md-6 mb-3 add_tags">
                    <input type="text" placeholder="Enter tag Name" id="tag-label-0" class='form-control' name='tag_label[]' maxlength="50" >
                    <span id="tag-label-error-0" class="err_msg"></span>
                </div>
            </div>


            <h5 class='my-3'>Add Suppliers <button class="btn btn-primary btn-sm" type='button' id='add-suppliers'>Add More +</button></h5>
            <div class="row appendSuppliers">
                <div class="col-md-6 mb-3 add_suppliers">
                    <input type="text" placeholder="Enter supplier Name" id="supplier-label-0" class='form-control' name='supplier_label[]' maxlength="50" >
                    <span id="supplier-label-error-0" class="err_msg"></span>
                </div>
            </div>
            

            <div class='d-flex justify-content-end'>
                    <button class='btn btn-sm me-2 reset-button' type="button"  id="reset-form">
                        <i class='mdi mdi-reload me-1'></i> Reset
                    </button>
                <button type="button" class="submit-btn btn btn-primary mb-4 float-end" onclick="store(event)">Create</button>
            </div>
            

        </div>
    </div>
</form>


@endsection