@extends('layouts.template')
@section('title', 'Customers Listings')
@section('body_class', '')
@section('content')

<div class="page-header">
<h3 class="page-title">
<span class="page-title-icon bg-gradient-primary text-white me-2">
<i class="mdi mdi-account-multiple"></i>
</span> Customers

</h3>


</div>



<div class="row">
<div class="col-lg-12 grid-margin stretch-card">
<div class="card">
<div class="card-body">

@if(count($customers) > 0)

    <div class="dataTable">
    <table class="table" id="search-data">

    
        <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Registered At</th>
        </tr>
        </thead>
        <tbody>
        
            @foreach ($customers as $key => $customer)
            <tr>
                <td>{{ $key + 1 }}</td>
                <td>{{ $customer->name  }}</td>
                <td>{{ $customer->email }}</td>
                <td>{{ \Carbon\Carbon::parse($customer->created_at)->format('M d, Y') }}</td>
            </tr>
            @endforeach

        </tbody>

        
        <tfoot>
        <!-- Individual column search -->
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Registered At</th>
        </tr>      
        </tfoot>



    </table>
    </div>

@else

<p class='m-0'>No Record Found</p>

@endif
    
</div>
</div>
</div>

</div>

@endsection